import sqlite3

con = sqlite3.connect("employee.db")
print("Database opened successfully")
# con.execute("DROP TABLE Employees")
# print("Table deleted")
con.execute("create table Employees(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,address TEXT NOT NULL)")
print("Employee Table created successfully")
con.close()